
                    $('#dob').datepicker({dateFormat: 'yy-mm-dd'});
                    $('#date_of_issue').datepicker({dateFormat: 'yy-mm-dd'});
                    $('#date_of_expiry').datepicker({dateFormat: 'yy-mm-dd'});