<?php defined('BASEPATH') || exit('No direct script access allowed');

$config['module_config'] = array(
	'description'	=> 'event_registration',
	'name'		    => 'Event Registration',
     /*
      * Replace the 'name' entry above with this entry and create the entry in
      * the application_lang file for localization/translation support in the
      * menu
     'name'          => 'lang:bf_menu_event_registration',
      */
	'version'		=> '0.0.1',
	'author'		=> 'admin',
);